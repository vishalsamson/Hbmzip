package com.cg.hbm.entites;

public class Transactions {
	private int transaction_id;
	private double amount;
}
