package com.cg.hbm.entites;

public class Admin {
	private int admin_id;
	private String admin_name;
	private String password;
	
}
