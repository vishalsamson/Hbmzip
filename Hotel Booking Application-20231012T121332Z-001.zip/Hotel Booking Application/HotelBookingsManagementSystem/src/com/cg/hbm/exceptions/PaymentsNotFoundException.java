package com.cg.hbm.exceptions;

public class PaymentsNotFoundException extends Exception {

}
