package com.cg.hbm.exceptions;

public class BookingDetailsNotFoundException extends Exception {

}
