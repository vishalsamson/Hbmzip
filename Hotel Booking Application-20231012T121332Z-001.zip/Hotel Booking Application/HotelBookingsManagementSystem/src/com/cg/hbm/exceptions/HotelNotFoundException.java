package com.cg.hbm.exceptions;

public class HotelNotFoundException extends Exception {

}
