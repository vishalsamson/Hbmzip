package com.cg.hbm.exceptions;

public class RoomDetailsNotFoundException extends Exception {

}
