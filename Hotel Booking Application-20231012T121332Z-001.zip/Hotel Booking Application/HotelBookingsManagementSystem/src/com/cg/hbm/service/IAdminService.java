package com.cg.hbm.service;

import com.cg.hbm.entites.Admin;

public interface IAdminService {
	public Admin signIn(Admin admin);
	public Admin signOut(Admin admin);
	
}
